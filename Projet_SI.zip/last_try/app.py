from flask import Flask,jsonify, render_template, request, redirect, url_for, flash, session
from flask_mysqldb import MySQL
from werkzeug.security import generate_password_hash, check_password_hash
import os
import MySQLdb.cursors
from datetime import datetime, timedelta


app = Flask(__name__)
app.secret_key = os.urandom(24)

# MySQL Configuration
app.config['MYSQL_HOST'] = 'localhost'
app.config['MYSQL_USER'] = 'root'
app.config['MYSQL_PASSWORD'] = 'assia2004'
app.config['MYSQL_DB'] = 'bibliothequ'

mysql = MySQL(app)

# Testez la connexion à la base de données
@app.before_request
def test_db_connection():
    try:
        cur = mysql.connection.cursor()
        cur.execute('SELECT 1')
        print("Connexion à la base de données réussie!")
    except Exception as e:
        print(f"Erreur de connexion à la base de données: {str(e)}")
    finally:
        if 'cur' in locals():
            cur.close()



# Routes
@app.route('/')
def home():
    cur = mysql.connection.cursor()
    cur.execute("SELECT d.*, l.auteurs, l.ISBN FROM documents d LEFT JOIN livres l ON d.reference = l.reference WHERE d.type_document = 'livre' ")
    books = cur.fetchall()
    cur.close()
    return render_template('home.html', books=books)



@app.route('/signup', methods=['GET', 'POST'])
def signup():
    if request.method == 'POST':
        try:
            # Récupérer les données du formulaire
            nom = request.form['nom']
            email = request.form['email']
            password = request.form['password']
            telephone = request.form['telephone']
            adresse = request.form['ville']
            categorie = request.form['categorie']
            
            # Créer un curseur
            cur = mysql.connection.cursor()
            
            # Exécuter l'insertion avec des prints de débogage
            print("Tentative d'insertion...")
            print(f"Données: {nom}, {email}, {password}, {telephone}, {adresse}, {categorie}")
            
            cur.execute("""
                INSERT INTO utilisateurs 
                (nom, email, mot_de_passe, telephone, ville, categorie, date_inscription) 
                VALUES (%s, %s, %s, %s, %s, %s, CURDATE())
            """, (nom, email, password, telephone, adresse, categorie))
            
            # IMPORTANT: Commit explicite
            mysql.connection.commit()
            
            # Vérification immédiate de l'insertion
            cur.execute("SELECT * FROM utilisateurs WHERE email = %s", (email,))
            user = cur.fetchone()
            print(f"Utilisateur inséré : {user}")
            
            flash('Inscription réussie!', 'success')
            cur.close()
            return redirect(url_for('login'))
            
        except Exception as e:
            print(f"Erreur lors de l'insertion : {str(e)}")
            flash(f'Erreur lors de l\'inscription: {str(e)}', 'error')
            if 'cur' in locals():
                cur.close()
            return render_template('signup.html')
            
    return render_template('signup.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        email = request.form['email']
        password = request.form['password']
        
        cur = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
        
        # Vérifier si c'est un admin
        cur.execute("SELECT * FROM admine WHERE email = %s AND mot_de_passe = %s", 
                   (email, password))
        admin = cur.fetchone()
        
        if admin:
            session['admin_id'] = admin['id_admin']
            session['admin_name'] = admin['nom']
            cur.close()
            return redirect(url_for('admin_dashboard'))
        
        # Vérifier si c'est un utilisateur
        cur.execute("SELECT * FROM utilisateurs WHERE email = %s AND mot_de_passe = %s", 
                   (email, password))
        user = cur.fetchone()
        
        if user:
            session['user_id'] = user['id_utilisateur']
            session['user_name'] = user['nom']
            cur.close()
            return redirect(url_for('user_dashboard'))
        
        flash('Email ou mot de passe incorrect', 'error')
        cur.close()
    
    return render_template('login.html')




# Ajoutez cette nouvelle route
@app.route('/statistics')
def statistics():
    cur = mysql.connection.cursor()
    
    # 1. Documents les plus empruntés
    cur.execute("""
        SELECT d.titre, COUNT(e.id_emprunt) as nombre_emprunts
        FROM documents d
        JOIN exemplaires ex ON d.reference = ex.reference_document
        JOIN emprunts e ON ex.id_exemplaire = e.id_exemplaire
        GROUP BY d.reference, d.titre
        ORDER BY nombre_emprunts DESC
        LIMIT 5
    """)
    most_borrowed = cur.fetchall()
    
    # 2. Répartition des utilisateurs par catégorie
    cur.execute("""
        SELECT categorie, COUNT(*) as nombre
        FROM utilisateurs
        GROUP BY categorie
    """)
    user_categories = cur.fetchall()
    
    # 3. Statistiques générales
    cur.execute("""
        SELECT 
            (SELECT COUNT(*) FROM documents) as total_documents,
            (SELECT COUNT(*) FROM emprunts WHERE statut = 'en cours') as emprunts_en_cours,
            (SELECT COUNT(*) FROM emprunts WHERE statut = 'retard') as emprunts_en_retard,
            (SELECT COUNT(*) FROM utilisateurs) as total_utilisateurs
    """)
    general_stats = cur.fetchone()
    
    cur.close()
    
    return render_template('statistics.html',
                         most_borrowed=most_borrowed,
                         user_categories=user_categories,
                         general_stats=general_stats)



#page admin
@app.route('/admin_dashboard')
def admin_dashboard():
    if 'admin_id' not in session:
        return redirect(url_for('login'))
    
    cur = mysql.connection.cursor()

    # Récupérer les documents avec plus d'informations
    cur.execute("""
        SELECT d.reference, d.titre, d.type_document, d.annee_publication, 
               d.editeur, d.description 
        FROM documents d
    """)
    documents = cur.fetchall()
    
    # Récupérer les utilisateurs avec les informations nécessaires
    cur.execute("""
        SELECT id_utilisateur, nom, categorie 
        FROM utilisateurs
    """)
    utilisateurs = cur.fetchall()
         # Récupérer les emprunts en cours avec tous les détails
    cur.execute("""
        SELECT 
            e.id_emprunt,
            u.nom AS nom_utilisateur,
            d.titre AS titre_document,
            DATE_FORMAT(e.date_debut, '%d/%m/%Y') AS date_debut,
            DATE_FORMAT(e.date_fin, '%d/%m/%Y') AS date_fin,
            e.statut,
            CASE 
                WHEN e.date_fin < CURRENT_DATE AND e.statut = 'en cours' THEN 'retard'
                ELSE e.statut 
            END AS statut_reel
        FROM emprunts e
        JOIN utilisateurs u ON e.id_utilisateur = u.id_utilisateur
        JOIN exemplaires ex ON e.id_exemplaire = ex.id_exemplaire
        JOIN documents d ON ex.reference_document = d.reference
        WHERE e.statut IN ('en cours', 'retard')
        ORDER BY e.date_fin ASC
    """)
    emprunts = cur.fetchall()
    print("Emprunts trouvés:", emprunts)  # Ajout de cette ligne pour le débogage

    cur.close()
    return render_template('admin_dashboard.html', 
                         documents=documents,
                         utilisateurs=utilisateurs,
                         emprunts=emprunts)



@app.route('/add_document', methods=['POST'])
def add_document():
    if 'admin_id' not in session:
        return redirect(url_for('login'))
    
    if request.method == 'POST':
        try:
            cur = mysql.connection.cursor()
            
            # Insertion dans la table documents
            query_doc = """
                INSERT INTO documents 
                (titre, annee_publication, editeur, type_document, description, langue) 
                VALUES (%s, %s, %s, %s, %s, %s)
            """
            values_doc = (
                request.form['titre'],
                request.form['annee'],
                request.form['editeur'],
                request.form['type_document'],
                request.form['description'],
                request.form['langue']
            )
            cur.execute(query_doc, values_doc)
            document_id = cur.lastrowid

            # Insertion selon le type de document
            if request.form['type_document'] == 'livre':
                query_livre = """
                    INSERT INTO livres 
                    (reference, auteurs, ISBN, genre, nombre_pages) 
                    VALUES (%s, %s, %s, %s, %s)
                """
                values_livre = (
                    document_id,
                    request.form.get('auteurs', ''),
                    request.form.get('isbn', ''),
                    request.form.get('genre', ''),
                    request.form.get('nombre_pages', 0)
                )
                cur.execute(query_livre, values_livre)
            else:
                query_periodique = """
                    INSERT INTO periodiques 
                    (reference, volume, numero, ISSN, periodicite) 
                    VALUES (%s, %s, %s, %s, %s)
                """
                values_periodique = (
                    document_id,
                    request.form.get('volume', ''),
                    request.form.get('numero', ''),
                    request.form.get('issn', ''),
                    request.form.get('periodicite', '')
                )
                cur.execute(query_periodique, values_periodique)

            # Ajout automatique d'un exemplaire
            query_exemplaire = """
                INSERT INTO exemplaires 
                (reference_document, date_achat, etat, statut, localisation) 
                VALUES (%s, CURRENT_DATE, 'Neuf', 'en rayon', 'Bibliothèque')
            """
            cur.execute(query_exemplaire, (document_id,))

            mysql.connection.commit()
            flash('Document et exemplaire ajoutés avec succès!', 'success')
            
        except Exception as e:
            print(f"Erreur: {str(e)}")
            mysql.connection.rollback()
            flash('Erreur lors de l\'ajout du document', 'error')
        finally:
            cur.close()
            
    return redirect(url_for('admin_dashboard'))



#page user
@app.route('/user_dashboard')
def user_dashboard():
    if 'user_id' not in session:
        return redirect(url_for('login'))
    
    # Création du curseur
    cur = mysql.connection.cursor()
    
    # Récupération des informations de l'utilisateur
    cur.execute("""
        SELECT nom, email, categorie
        FROM utilisateurs
        WHERE id_utilisateur= %s
    """, (session['user_id'],))
    
    user_info = cur.fetchone()
    
    if not user_info:
        cur.close()
        session.clear()
        return redirect(url_for('login'))
    
    # Récupération des emprunts
    cur.execute("""
        SELECT d.titre, e.date_debut, e.date_fin, e.statut
        FROM emprunts e
        JOIN exemplaires ex ON e.id_exemplaire = ex.id_exemplaire
        JOIN documents d ON ex.reference_document = d.reference
        WHERE e.id_utilisateur = %s
    """, (session['user_id'],))
    
    emprunts = cur.fetchall()
    
    # Création d'un dictionnaire avec les informations de l'utilisateur
    user = {
        'nom': user_info[0],
        'email': user_info[1],
        'categorie': user_info[2]
    }
    
    cur.close()
    
    return render_template('user_dashboard.html',
                         user=user,
                         emprunts=emprunts,
                         current_date=datetime.now())



@app.route('/search')
def search():
    query = request.args.get('query', '').strip()
    search_type = request.args.get('type', 'all')
    category = request.args.get('category', 'all')  # Nouveau paramètre pour la catégorie
    
    if not query and category == 'all':
        if 'user_id' in session:
            return render_template('user_dashboard.html', results=[], emprunts=[], query='', search_type='all', category='all')
        return render_template('search_results.html', results=[], query='', search_type='all', category='all')
    
    cur = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
    
    # Construction de la condition WHERE selon le type de recherche et la catégorie
    where_conditions = []
    params = {}
    
    # Gestion de la recherche par type
    if query:
        if search_type == 'title':
            where_conditions.append("d.titre LIKE %(query)s")
            params['query'] = f'%{query}%'
        elif search_type == 'author':
            where_conditions.append("l.auteurs LIKE %(query)s")
            params['query'] = f'%{query}%'
        else:  # 'all'
            where_conditions.append("""(d.titre LIKE %(query)s 
                                    OR l.auteurs LIKE %(query)s)""")
            params['query'] = f'%{query}%'
    
    # Ajout de la condition de catégorie
    if category != 'all':
        where_conditions.append("d.type_document = %(category)s")
        params['category'] = category
    
    # Construction de la clause WHERE finale
    where_clause = "WHERE " + " AND ".join(where_conditions) if where_conditions else ""
    
    search_query = f"""
    SELECT 
        d.reference,
        d.titre,
        d.type_document,
        d.annee_publication,
        d.editeur,
        l.auteurs,
        l.ISBN,
        (SELECT COUNT(*) FROM exemplaires e
         WHERE e.reference_document = d.reference
         AND e.statut = 'en rayon') as disponibles
    FROM documents d
    LEFT JOIN livres l ON d.reference = l.reference
    {where_clause}
    ORDER BY d.titre
    """
    
    try:
        cur.execute(search_query, params)
        results = cur.fetchall()
        
        # Récupérer la liste des catégories pour le formulaire de recherche
        cur.execute("""
            SELECT DISTINCT type_document 
            FROM documents 
            ORDER BY type_document
        """)
        categories = [row['type_document'] for row in cur.fetchall()]
        
        if 'user_id' in session:
            # Récupérer les emprunts pour le dashboard utilisateur
            cur.execute("""
                SELECT
                    d.titre,
                    DATE_FORMAT(e.date_debut, '%d/%m/%Y') as date_debut,
                    DATE_FORMAT(e.date_fin, '%d/%m/%Y') as date_fin,
                    CASE
                        WHEN e.date_fin < CURRENT_DATE THEN 'retard'
                        ELSE e.statut
                    END as statut
                FROM emprunts e
                JOIN exemplaires ex ON e.id_exemplaire = ex.id_exemplaire
                JOIN documents d ON ex.reference_document = d.reference
                WHERE e.id_utilisateur = %s
                ORDER BY e.date_debut DESC
            """, (session['user_id'],))
            emprunts = cur.fetchall()
            
            return render_template('user_dashboard.html',
                               results=results,
                               emprunts=emprunts,
                               query=query,
                               search_type=search_type,
                               category=category,
                               categories=categories)
        else:
            return render_template('search_results.html',
                               results=results,
                               query=query,
                               search_type=search_type,
                               category=category,
                               categories=categories)
            
    except Exception as e:
        print(f"Erreur de recherche: {e}")  # Pour le débogage
        if 'user_id' in session:
            return render_template('user_dashboard.html',
                               results=[],
                               emprunts=[],
                               query=query,
                               search_type=search_type,
                               category=category,
                               categories=[])
        return render_template('search_results.html',
                           results=[],
                           query=query,
                           search_type=search_type,
                           category=category,
                           categories=[])
    
    finally:
        cur.close()

#gestion des emprunts
@app.route('/request_borrow/<int:document_id>', methods=['POST'])
def request_borrow(document_id):
    # Vérification de la connexion utilisateur
    if 'user_id' not in session:
        return jsonify({'success': False, 'message': 'Veuillez vous connecter'}), 401
    
    try:
        cur = mysql.connection.cursor()
        
        # 1. Vérification de la catégorie de l'utilisateur et du nombre d'emprunts en cours
        cur.execute("""
            SELECT categorie, 
                   (SELECT COUNT(*) FROM emprunts 
                    WHERE id_utilisateur = utilisateurs.id_utilisateur 
                    AND statut = 'en cours' ) as nb_emprunts
            FROM utilisateurs 
            WHERE id_utilisateur = %s
        """, (session['user_id'],))
        
        user_info = cur.fetchone()
        if not user_info:
            return jsonify({'success': False, 'message': 'Utilisateur non trouvé'}), 404
            
        # Vérification des limites d'emprunt selon la catégorie
        limite_emprunts = {
            'occasionnel': 1,
            'abonne': 4,
            'abonne_privilegie': 8
        }
        
        if user_info[1] >= limite_emprunts[user_info[0]]:
            return jsonify({
                'success': False, 
                'message': f'Limite d\'emprunts atteinte pour votre catégorie ({user_info[0]})'
            }), 400
        
        # 2. Vérification de la disponibilité d'un exemplaire
        cur.execute("""
            SELECT id_exemplaire 
            FROM exemplaires 
            WHERE reference_document = %s AND statut = 'en rayon' 
            LIMIT 1
        """, (document_id,))
        
        exemplaire = cur.fetchone()
        if not exemplaire:
            return jsonify({
                'success': False, 
                'message': 'Aucun exemplaire disponible pour ce document'
            }), 400
            
        # 3. Création de l'emprunt
        # Date de fin selon la catégorie
        duree_pret = {
            'occasionnel': 15,  # 2 semaines
            'abonne': 30,       # 1 mois
            'abonne_privilegie': 30  # 1 mois
        }
        
        cur.execute("""
            INSERT INTO emprunts 
                (id_utilisateur, id_exemplaire, date_debut, date_fin, statut) 
            VALUES 
                (%s, %s, CURRENT_DATE, DATE_ADD(CURRENT_DATE, INTERVAL %s DAY), 'en cours')
        """, (session['user_id'], exemplaire[0], duree_pret[user_info[0]]))
        
        # 4. Mise à jour du statut de l'exemplaire
        cur.execute("""
            UPDATE exemplaires 
            SET statut = 'en prêt' 
            WHERE id_exemplaire = %s
        """, (exemplaire[0],))
            
        mysql.connection.commit()
        cur.close()
        
        return jsonify({
            'success': True, 
            'message': f'Emprunt effectué avec succès. Retour prévu dans {duree_pret[user_info[0]]} jours.'
        })
        
    except Exception as e:
        mysql.connection.rollback()
        print(f"Erreur lors de l'emprunt: {str(e)}")  # Pour le debugging
        return jsonify({
            'success': False, 
            'message': 'Une erreur est survenue lors de l\'emprunt'
        }), 500
@app.route('/api/exemplaires-disponibles/<int:document_id>')
def get_exemplaires_disponibles(document_id):
    cur = mysql.connection.cursor()
    cur.execute("""
        SELECT id_exemplaire, etat 
        FROM exemplaires 
        WHERE reference_document = %s AND statut = 'en rayon'
    """, (document_id,))
    exemplaires = [{'id_exemplaire': e[0], 'etat': e[1]} for e in cur.fetchall()]
    cur.close()
    return jsonify({'exemplaires': exemplaires})

@app.route('/api/creer-emprunt', methods=['POST'])
def creer_emprunt():
    data = request.json
    try:
        cur = mysql.connection.cursor()
        
        # Vérifier si l'exemplaire est toujours disponible
        cur.execute("""
            SELECT statut FROM exemplaires 
            WHERE id_exemplaire = %s
        """, (data['id_exemplaire'],))
        if cur.fetchone()[0] != 'en rayon':
            return jsonify({
                'success': False,
                'message': 'Cet exemplaire n\'est plus disponible'
            })

        # Créer l'emprunt
        cur.execute("""
            INSERT INTO emprunts (id_utilisateur, id_exemplaire, date_debut, date_fin, statut)
            VALUES (%s, %s, CURRENT_DATE, DATE_ADD(CURRENT_DATE, INTERVAL 14 DAY), 'en cours')
        """, (data['id_utilisateur'], data['id_exemplaire']))
        
        # Mettre à jour le statut de l'exemplaire
        cur.execute("""
            UPDATE exemplaires SET statut = 'en prêt'
            WHERE id_exemplaire = %s
        """, (data['id_exemplaire'],))
        
        mysql.connection.commit()
        cur.close()
        return jsonify({'success': True})
    except Exception as e:
        print(f"Erreur: {str(e)}")
        return jsonify({
            'success': False,
            'message': 'Erreur lors de la création de l\'emprunt'
        })
@app.route('/delete_document/<int:reference>', methods=['POST'])
def delete_document(reference):
    if 'admin_id' not in session:
        return jsonify({'success': False, 'message': 'Non autorisé'}), 403
        
    try:
        cur = mysql.connection.cursor()
        
        # Vérifier s'il y a des emprunts en cours
        cur.execute("""
            SELECT COUNT(*) FROM emprunts e
            JOIN exemplaires ex ON e.id_exemplaire = ex.id_exemplaire
            WHERE ex.reference_document = %s AND e.statut = 'en cours'or 'retard'
        """, (reference,))
        
        if cur.fetchone()[0] > 0:
            return jsonify({
                'success': False,
                'message': 'Impossible de supprimer ce document : des emprunts sont en cours'
            })
        
        # Supprimer les enregistrements liés
        cur.execute("DELETE FROM exemplaires WHERE reference_document = %s", (reference,))
        cur.execute("DELETE FROM livres WHERE reference = %s", (reference,))
        cur.execute("DELETE FROM periodiques WHERE reference = %s", (reference,))
        cur.execute("DELETE FROM documents WHERE reference = %s", (reference,))
        
        mysql.connection.commit()
        return jsonify({'success': True, 'message': 'Document supprimé avec succès'})
        
    except Exception as e:
        mysql.connection.rollback()
        return jsonify({'success': False, 'message': str(e)})
    finally:
        cur.close()

@app.route('/get_document/<int:reference>')
def get_document(reference):
    if 'admin_id' not in session:
        return jsonify({'success': False, 'message': 'Non autorisé'}), 403
        
    try:
        cur = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
        
        # Récupérer les informations du document
        cur.execute("""
            SELECT d.*, l.auteurs, l.ISBN, l.genre, l.nombre_pages,
                   p.volume, p.numero, p.ISSN, p.periodicite
            FROM documents d
            LEFT JOIN livres l ON d.reference = l.reference
            LEFT JOIN periodiques p ON d.reference = p.reference
            WHERE d.reference = %s
        """, (reference,))
        
        document = cur.fetchone()
        return jsonify({'success': True, 'document': document})
        
    except Exception as e:
        return jsonify({'success': False, 'message': str(e)})
    finally:
        cur.close()

@app.route('/update_document/<int:reference>', methods=['POST'])
def update_document(reference):
    if 'admin_id' not in session:
        return jsonify({'success': False, 'message': 'Non autorisé'}), 403
    
    try:
        cur = mysql.connection.cursor()
        
        # Mise à jour de la table documents
        cur.execute("""
            UPDATE documents 
            SET titre = %s, annee_publication = %s, editeur = %s,
                type_document = %s, description = %s, langue = %s
            WHERE reference = %s
        """, (
            request.json['titre'],
            request.json['annee'],
            request.json['editeur'],
            request.json['type_document'],
            request.json['description'],
            request.json['langue'],
            reference
        ))
        
        # Mise à jour selon le type de document
        if request.json['type_document'] == 'livre':
            cur.execute("""
                UPDATE livres 
                SET auteurs = %s, ISBN = %s, genre = %s, nombre_pages = %s
                WHERE reference = %s
            """, (
                request.json.get('auteurs', ''),
                request.json.get('isbn', ''),
                request.json.get('genre', ''),
                request.json.get('nombre_pages', 0),
                reference
            ))
        else:
            cur.execute("""
                UPDATE periodiques 
                SET volume = %s, numero = %s, ISSN = %s, periodicite = %s
                WHERE reference = %s
            """, (
                request.json.get('volume', ''),
                request.json.get('numero', ''),
                request.json.get('issn', ''),
                request.json.get('periodicite', ''),
                reference
            ))
        
        mysql.connection.commit()
        return jsonify({'success': True, 'message': 'Document mis à jour avec succès'})
        
    except Exception as e:
        mysql.connection.rollback()
        return jsonify({'success': False, 'message': str(e)})
    finally:
        cur.close()
        
@app.route('/api/marquer-rendu/<int:id_emprunt>', methods=['POST'])
def marquer_rendu(id_emprunt):
    if 'admin_id' not in session:
        return jsonify({'success': False, 'message': 'Non autorisé'}), 403
    
    try:
        cur = mysql.connection.cursor()
        
        # Vérifier si l'emprunt existe et n'est pas déjà rendu
        cur.execute("SELECT id_exemplaire, statut FROM emprunts WHERE id_emprunt = %s", (id_emprunt,))
        emprunt = cur.fetchone()
        
        if not emprunt:
            return jsonify({'success': False, 'message': 'Emprunt non trouvé'}), 404
        
        if emprunt[1] == 'rendu':
            return jsonify({'success': False, 'message': 'Emprunt déjà rendu'}), 400
        
        # Mettre à jour le statut de l'emprunt
        cur.execute("""
            UPDATE emprunts 
            SET statut = 'rendu', date_retour = CURRENT_TIMESTAMP 
            WHERE id_emprunt = %s
        """, (id_emprunt,))
        
        # Mettre à jour le statut de l'exemplaire
        cur.execute("""
            UPDATE exemplaires 
            SET statut = 'en rayon' 
            WHERE id_exemplaire = %s
        """, (emprunt[0],))
        
        mysql.connection.commit()
        cur.close()
        
        return jsonify({'success': True, 'message': 'Emprunt marqué comme rendu'})
        
    except Exception as e:
        return jsonify({'success': False, 'message': str(e)}), 500



#logout(user & admin)
@app.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('home'))


#main(python)
if __name__ == '__main__':
    app.run(debug=True)